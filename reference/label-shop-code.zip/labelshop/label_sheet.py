#!/usr/bin/env python3
"""
label_sheet.py - personalised name-label sheets for print & cut (Epson ET-2980 + Silhouette Cameo 5).

Commands
  python label_sheet.py order orders/sample_order.json     build print PDF + cut files + proofs for an order
  python label_sheet.py fontchart                          font chart image for the Etsy listing
  python label_sheet.py themes --name "Emma"               theme sampler (listing photos), add --finish holographic
  python label_sheet.py packs                              sheets needed per pack + Etsy variation table

Everything about sizes, packs, finishes, fonts and designs lives in config/*.json.
Output goes to out/<order id>/<finish>/ :
  print.pdf          print this (100 % scale, one sheet at a time)
  cut_pNN.dxf/.svg   kiss-cut lines for page NN (import into Silhouette Studio)
  proof_pNN.png      page preview with cut lines in red, check before printing
  info.txt           where to place the cut file in Studio + laminate notes
and out/<order id>/customer_proof.png to send to the buyer for a spelling check.
"""
import argparse
import csv
import hashlib
import json
import math
import random
import sys
import unicodedata
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parent

# ---------------------------------------------------------------- page / machine constants
PAGE_W, PAGE_H = 215.9, 279.4   # US Letter, mm
MARGIN = 12.0        # no ink closer than this to any sheet edge
REG_KEEPOUT = 36.0   # square kept clear at top-left, top-right, bottom-left for Studio's Type 1 marks
                     # (inset 10 + length 20 + a safety band for the hatched no-ink zone)
LAMINATE_NOTCH = 34.0  # corner squares cut off shiny laminate so the marks stay readable
GAP = 3.0            # space between neighbouring cut lines
BLEED = 1.25         # artwork extends this far past every cut line (hides small cut offsets)
SAFE = 1.0           # text/icons stay at least this far inside the cut line
DPI = 600            # label render resolution
MIN_CAP_MM = 1.7     # warn if capital letters end up smaller than this (hard to read)
K = DPI / 25.4       # pixels per mm


def px(v_mm):
    return int(round(v_mm * K))


def load_json(name, override=None):
    p = Path(override) if override else ROOT / "config" / name
    return json.loads(p.read_text(encoding="utf-8"))


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def warn(msg):
    print("  WARNING:", msg)


# ---------------------------------------------------------------- fonts
class FontStore:
    def __init__(self, cfg, fonts_dir):
        self.entries = {f["id"]: f for f in cfg["fonts"]}
        self.dir = Path(fonts_dir)
        self.sample = cfg.get("sample_text", "Émilie-Rose")
        self._cache = {}
        self._cmaps = {}

    def path(self, fid):
        e = self.entries.get(fid)
        if e is None:
            raise SystemExit(f"Font {fid} is not in config/fonts.json")
        p = Path(e["file"])
        p = p if p.is_absolute() else self.dir / p
        if not p.exists():
            raise SystemExit(f"Font file missing: {p}\nRun: python get_fonts.py")
        return p

    def get(self, fid, size):
        key = (fid, size)
        if key not in self._cache:
            e = self.entries[fid]
            f = ImageFont.truetype(str(self.path(fid)), size)
            if e.get("weight"):
                try:
                    vals = []
                    for ax in f.get_variation_axes():
                        nm = ax.get("name", b"")
                        nm = nm.decode() if isinstance(nm, bytes) else str(nm)
                        if nm.lower().startswith("weight"):
                            vals.append(max(ax["minimum"], min(ax["maximum"], e["weight"])))
                        else:
                            vals.append(ax.get("default", ax["minimum"]))
                    f.set_variation_by_axes(vals)
                except Exception:
                    pass  # static font, or FreeType without variation support
            self._cache[key] = f
        return self._cache[key]

    def missing_glyphs(self, fid, text):
        if fid not in self._cmaps:
            try:
                from fontTools.ttLib import TTFont
                self._cmaps[fid] = set(TTFont(str(self.path(fid)), lazy=True).getBestCmap().keys())
            except Exception:
                self._cmaps[fid] = None
        cmap = self._cmaps[fid]
        if cmap is None:
            return []
        return sorted({c for c in text if not c.isspace() and ord(c) not in cmap})


# ---------------------------------------------------------------- backgrounds and motifs
def gradient(w, h, colors, angle):
    if len(colors) == 1:
        return Image.new("RGB", (w, h), hex_rgb(colors[0]))
    a = math.radians(angle)
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    t = xs * math.cos(a) + ys * math.sin(a)
    t = (t - t.min()) / max(1e-6, (t.max() - t.min()))
    stops = np.array([hex_rgb(c) for c in colors], dtype=np.float32)
    pos = t * (len(stops) - 1)
    i0 = np.clip(np.floor(pos).astype(int), 0, len(stops) - 2)
    f = (pos - i0)[..., None]
    out = stops[i0] * (1 - f) + stops[i0 + 1] * f
    return Image.fromarray(out.astype(np.uint8), "RGB")


def star_poly(cx, cy, r, rot, inner=0.48, points=5):
    pts = []
    for i in range(points * 2):
        rr = r if i % 2 == 0 else r * inner
        a = rot + math.pi * i / points - math.pi / 2
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return pts


def rot_rect(cx, cy, w, h, ang):
    c, s = math.cos(ang), math.sin(ang)
    return [(cx + x * c - y * s, cy + x * s + y * c)
            for x, y in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]


def motif_layer(w, h, m, rng):
    """Returns an RGBA layer (or None) with the theme's pattern."""
    typ = m.get("type", "none")
    if typ == "none":
        return None
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cols = [hex_rgb(c) for c in m.get("colors", ["#FFFFFF"])]
    smin, smax = (m.get("size_mm") or [1, 2])[:2]
    area = (w / K) * (h / K)
    count = int(m.get("density", 0.5) * area / 20)

    if typ == "stars":
        for _ in range(count):
            x, y = rng.uniform(0, w), rng.uniform(0, h)
            s = rng.uniform(smin, smax) * K
            c = rng.choice(cols)
            if rng.random() < 0.35:
                r = s * 0.18
                d.ellipse((x - r, y - r, x + r, y + r), fill=c + (255,))
            else:
                d.polygon(star_poly(x, y, s / 2, rng.uniform(0, 1.3)), fill=c + (255,))
    elif typ == "confetti":
        for _ in range(count):
            x, y = rng.uniform(0, w), rng.uniform(0, h)
            s = rng.uniform(smin, smax) * K
            c = rng.choice(cols) + (255,)
            if rng.random() < 0.4:
                d.ellipse((x - s / 3, y - s / 3, x + s / 3, y + s / 3), fill=c)
            else:
                d.polygon(rot_rect(x, y, s, s * 0.42, rng.uniform(0, math.pi)), fill=c)
    elif typ == "sprinkles":
        lw = max(2, int(smax * K))
        for _ in range(count):
            x, y = rng.uniform(0, w), rng.uniform(0, h)
            L = smin * K * rng.uniform(0.8, 1.2)
            a = rng.uniform(0, math.pi)
            dx, dy = math.cos(a) * L / 2, math.sin(a) * L / 2
            c = rng.choice(cols) + (255,)
            d.line((x - dx, y - dy, x + dx, y + dy), fill=c, width=lw)
            for ex, ey in ((x - dx, y - dy), (x + dx, y + dy)):
                d.ellipse((ex - lw / 2, ey - lw / 2, ex + lw / 2, ey + lw / 2), fill=c)
    elif typ == "flowers":
        for _ in range(count):
            x, y = rng.uniform(0, w), rng.uniform(0, h)
            s = rng.uniform(smin, smax) * K
            c = rng.choice(cols) + (255,)
            pr = s * 0.24
            rot = rng.uniform(0, 1.2)
            for i in range(5):
                a = rot + i * 2 * math.pi / 5
                px_, py_ = x + math.cos(a) * s * 0.28, y + math.sin(a) * s * 0.28
                d.ellipse((px_ - pr, py_ - pr, px_ + pr, py_ + pr), fill=c)
            d.ellipse((x - pr * 0.6, y - pr * 0.6, x + pr * 0.6, y + pr * 0.6), fill=(255, 214, 10, 255))
    elif typ == "dots":
        r = smin * K / 2
        sp = smax * K
        row = 0
        y = -sp
        while y < h + sp:
            x = -sp + (sp / 2 if row % 2 else 0)
            while x < w + sp:
                d.ellipse((x - r, y - r, x + r, y + r), fill=cols[0] + (255,))
                x += sp
            y += sp * 0.87
            row += 1
    elif typ in ("stripes", "checker"):
        ys, xs = np.mgrid[0:h, 0:w].astype(np.float32) / K
        a = math.radians(m.get("angle", 0))
        u = xs * math.cos(a) + ys * math.sin(a)
        v = -xs * math.sin(a) + ys * math.cos(a)
        size = smin
        arr = np.zeros((h, w, 4), np.uint8)
        if typ == "stripes":
            idx = np.floor(u / size).astype(int) % len(cols)
            pal = np.array(cols, np.uint8)
            arr[..., :3] = pal[idx]
            arr[..., 3] = 255
        else:
            on = (np.floor(u / size) + np.floor(v / size)).astype(int) % 2 == 1
            arr[on, :3] = cols[0]
            arr[on, 3] = 255
        layer = Image.fromarray(arr, "RGBA")
    elif typ == "waves":
        spacing, lw_mm = smin * K, smax
        lw = max(2, int(lw_mm * K))
        amp, wl = 0.55 * K, 5.0 * K
        y0 = spacing / 2
        while y0 < h + spacing:
            pts = [(x, y0 + amp * math.sin(2 * math.pi * x / wl + y0)) for x in range(-10, w + 10, 6)]
            d.line(pts, fill=cols[0] + (255,), width=lw, joint="curve")
            y0 += spacing
    op = float(m.get("opacity", 1.0))
    if op < 1:
        a = layer.getchannel("A").point(lambda v: int(v * op))
        layer.putalpha(a)
    return layer


def tile_pattern(path, w, h, tile_mm, mode="repeat"):
    """Fill w x h px with a pattern image repeated every tile_mm. mode 'mirror' flips alternate
    tiles, which hides seams on patterns that aren't perfectly seamless."""
    t = Image.open(path).convert("RGB")
    tp = max(8, px(tile_mm))
    t = t.resize((tp, tp), Image.LANCZOS)
    if mode == "mirror":
        quad = Image.new("RGB", (tp * 2, tp * 2))
        quad.paste(t, (0, 0))
        quad.paste(t.transpose(Image.FLIP_LEFT_RIGHT), (tp, 0))
        quad.paste(t.transpose(Image.FLIP_TOP_BOTTOM), (0, tp))
        quad.paste(t.transpose(Image.ROTATE_180), (tp, tp))
        t, tp = quad, tp * 2
    out = Image.new("RGB", (w, h))
    for y in range(0, h, tp):
        for x in range(0, w, tp):
            out.paste(t, (x, y))
    return out


# ---------------------------------------------------------------- scene designs (Flow art)
_SCENE_CACHE = {}


def trimmed_strip(path):
    """Wide art is generated as a strip on a white letterbox: cut the white bands off."""
    key = str(path)
    if key not in _SCENE_CACHE:
        im = Image.open(path).convert("RGB")
        g = np.asarray(im.convert("L")).astype(np.float32)
        rows = np.where(g.mean(1) < 245)[0]
        if len(rows) and (rows.max() - rows.min()) < im.height * 0.95:
            im = im.crop((0, rows.min() + 4, im.width, rows.max() - 3))
        _SCENE_CACHE[key] = im
    return _SCENE_CACHE[key]


def cover(im, w, h, x_frac=0.0, y_frac=0.5):
    """Scale im to cover w x h, then crop; x_frac/y_frac choose where the crop window sits (0 = left/top)."""
    sc = max(w / im.width, h / im.height)
    r = im.resize((max(w, int(round(im.width * sc))), max(h, int(round(im.height * sc)))), Image.LANCZOS)
    x = int(round((r.width - w) * x_frac))
    y = int(round((r.height - h) * y_frac))
    return r.crop((x, y, x + w, y + h)), sc


def scene_render(th, tdir, s, size_id, wpx, hpx):
    """Background + text box (mm, relative to cut box) for a Flow scene design."""
    sc_cfg = th["scene"]
    w, h = s["w"], s["h"]
    crops_file = tdir / "crops.json"
    if crops_file.exists():
        preset = json.loads(crops_file.read_text(encoding="utf-8")).get(size_id)
        if preset:
            return crop_preset(preset, sc_cfg, tdir, s, wpx, hpx)
    squareish = s["shape"] == "round" or h >= w * 0.8
    if squareish:
        img, _ = cover(Image.open(tdir / sc_cfg.get("square", "square.jpg")).convert("RGB"), wpx, hpx, 0.5, 0.5)
        x0, y0, x1, y1 = sc_cfg.get("square_text", [0.14, 0.17, 0.86, 0.40])
        return img, (w * x0, h * y0, w * x1, h * y1)
    strip = trimmed_strip(tdir / sc_cfg.get("wide", "wide.jpg"))
    sc = hpx / strip.height
    sw = strip.width * sc
    if size_id in sc_cfg.get("no_character_sizes", []):
        start = sc_cfg.get("mini_start", 0.24) * sw
        xf = min(1.0, start / max(1, sw - wpx))
        img, _ = cover(strip, wpx, hpx, xf, 0.5)
        pad = max(SAFE, s.get("r", 0) * 0.4)
        return img, (pad, pad * 0.6, w - pad, h - pad * 0.6)
    img, _ = cover(strip, wpx, hpx, 0.0, 0.5)
    char_end_mm = sc_cfg.get("char_end", 0.20) * sw / K - BLEED
    pad = max(SAFE, s.get("r", 0) * 0.45)
    return img, (char_end_mm + 1.0, pad * 0.7, w - pad, h - pad * 0.7)


def crop_preset(preset, sc_cfg, tdir, s, wpx, hpx):
    """Per-design crop saved once per size in themes/<id>/crops.json:
      "mini": {"source": "wide", "center": [0.30, 0.50], "height": 1.0, "text": [0.35, 0.10, 0.96, 0.90]}
    source  wide | square        which artwork to crop
    center  crop centre, as fractions of the source image (the wide one is measured after the white bands are trimmed)
    height  crop height as a fraction of the source height; the width follows the label shape automatically
    text    name box as fractions of the cut label (x0, y0, x1, y1)"""
    if preset.get("source", "wide") == "square":
        src = Image.open(tdir / sc_cfg.get("square", "square.jpg")).convert("RGB")
    else:
        src = trimmed_strip(tdir / sc_cfg.get("wide", "wide.jpg"))
    ch = preset.get("height", 1.0) * src.height
    cw = ch * wpx / hpx
    if cw > src.width:
        cw = src.width
        ch = cw * hpx / wpx
    cx, cy = preset.get("center", [0.5, 0.5])
    x0 = min(max(0, cx * src.width - cw / 2), src.width - cw)
    y0 = min(max(0, cy * src.height - ch / 2), src.height - ch)
    img = src.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((wpx, hpx), Image.LANCZOS)
    tx0, ty0, tx1, ty1 = preset.get("text", [0.1, 0.1, 0.9, 0.9])
    return img, (s["w"] * tx0, s["h"] * ty0, s["w"] * tx1, s["h"] * ty1)


# ---------------------------------------------------------------- icons
def heart_poly(cx, cy, s):
    pts = []
    for i in range(80):
        t = 2 * math.pi * i / 80
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((cx + x * s / 34, cy - y * s / 34 - s * 0.03))
    return pts


def icon_image(spec, s):
    """RGBA icon of s x s pixels with an outline ring for contrast."""
    s = max(8, int(s))
    pad = s * 0.09
    inner = s - 2 * pad
    cx = cy = s / 2
    mask = Image.new("L", (s, s), 0)
    md = ImageDraw.Draw(mask)
    color = hex_rgb(spec.get("color", "#FFFFFF"))
    fill = Image.new("RGBA", (s, s), color + (255,))
    t = spec.get("type", "star")
    if t == "star":
        md.polygon(star_poly(cx, cy + inner * 0.04, inner / 2, 0, inner=0.5), fill=255)
    elif t == "heart":
        md.polygon(heart_poly(cx, cy, inner), fill=255)
    elif t == "moon":
        r = inner / 2
        md.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
        cut = Image.new("L", (s, s), 0)
        ImageDraw.Draw(cut).ellipse((cx - r + r * 0.55, cy - r - r * 0.25, cx + r + r * 0.55, cy + r - r * 0.25), fill=255)
        mask = ImageChops.subtract(mask, cut)
    elif t == "flower":
        pr = inner * 0.22
        for i in range(5):
            a = -math.pi / 2 + i * 2 * math.pi / 5
            x, y = cx + math.cos(a) * inner * 0.27, cy + math.sin(a) * inner * 0.27
            md.ellipse((x - pr, y - pr, x + pr, y + pr), fill=255)
        md.ellipse((cx - pr, cy - pr, cx + pr, cy + pr), fill=255)
    elif t == "drop":
        r = inner * 0.33
        by = cy + inner * 0.17
        md.ellipse((cx - r, by - r, cx + r, by + r), fill=255)
        md.polygon([(cx, cy - inner / 2), (cx - r * 0.97, by - r * 0.25), (cx + r * 0.97, by - r * 0.25)], fill=255)
    elif t == "bolt":
        u = inner
        x0, y0 = cx - u / 2, cy - u / 2
        pts = [(0.58, 0.0), (0.18, 0.55), (0.46, 0.55), (0.36, 1.0), (0.82, 0.40), (0.54, 0.40), (0.70, 0.0)]
        md.polygon([(x0 + a * u, y0 + b * u) for a, b in pts], fill=255)
    elif t == "rainbow":
        bands = ["#FF595E", "#FFCA3A", "#8AC926", "#1982C4", "#6A4C93"]
        R = inner / 2
        bw = R * 0.62 / len(bands)
        base = cy + inner * 0.22
        fd = ImageDraw.Draw(fill)
        fill.paste((255, 255, 255, 255), (0, 0, s, s))
        for i, c in enumerate(bands):
            rr = R - i * bw
            fd.pieslice((cx - rr, base - rr, cx + rr, base + rr), 180, 360, fill=hex_rgb(c) + (255,))
        rr = R - len(bands) * bw
        fd.pieslice((cx - rr, base - rr, cx + rr, base + rr), 180, 360, fill=(0, 0, 0, 0))
        md.pieslice((cx - R, base - R, cx + R, base + R), 180, 360, fill=255)
        md.pieslice((cx - rr, base - rr, cx + rr, base + rr), 180, 360, fill=0)
    out = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    if spec.get("outline"):
        ring = mask.filter(ImageFilter.GaussianBlur(s * 0.045)).point(lambda v: 255 if v > 8 else 0)
        ring = ring.filter(ImageFilter.GaussianBlur(1.2))
        out.paste(Image.new("RGBA", (s, s), hex_rgb(spec["outline"]) + (255,)), (0, 0), ring)
    out.paste(fill, (0, 0), mask)
    if t == "flower":
        pr = inner * 0.12
        ImageDraw.Draw(out).ellipse((cx - pr, cy - pr, cx + pr, cy + pr), fill=hex_rgb(spec.get("center", "#FFD23F")) + (255,))
    return out


# ---------------------------------------------------------------- text
def fit_text(fonts, fid, text, max_w, max_h, stroke_ratio, cap_frac=0.62):
    """Largest font size where the text fits the box. Returns (font, stroke px, bbox, cap px)."""
    lo, hi, best = 6, int(max_h * 1.8), None
    while lo <= hi:
        mid = (lo + hi) // 2
        f = fonts.get(fid, mid)
        cap = -f.getbbox("H", anchor="ls")[1]
        sw = int(round(stroke_ratio * cap)) if stroke_ratio else 0
        bb = f.getbbox(text, anchor="ls", stroke_width=sw)
        if bb[2] - bb[0] <= max_w and bb[3] - bb[1] <= max_h and cap <= max_h * cap_frac:
            best = (f, sw, bb, cap)
            lo = mid + 1
        else:
            hi = mid - 1
    if best is None:
        f = fonts.get(fid, 6)
        best = (f, 0, f.getbbox(text, anchor="ls"), -f.getbbox("H", anchor="ls")[1])
    return best


def draw_text_block(img, fonts, fid, lines, box, style, cap_frac=0.62):
    """box = (x0, y0, x1, y1) in px. lines = 1 or 2 strings. Returns smallest cap height in mm."""
    x0, y0, x1, y1 = box
    d = ImageDraw.Draw(img)
    fill = hex_rgb(style.get("fill", "#000000"))
    stroke = hex_rgb(style["stroke"]) if style.get("stroke") else None
    ratio = style.get("stroke_ratio", 0) if stroke else 0
    H = y1 - y0
    if len(lines) == 2 and lines[1]:
        gap = H * 0.04
        rows = [(lines[0], y0, y0 + H * 0.60), (lines[1], y0 + H * 0.60 + gap, y1)]
    else:
        rows = [(lines[0], y0, y1)]
    caps = []
    for text, ry0, ry1 in rows:
        f, sw, bb, cap = fit_text(fonts, fid, text, x1 - x0, ry1 - ry0, ratio, cap_frac)
        cx, cy = (x0 + x1) / 2, (ry0 + ry1) / 2
        x = cx - (bb[0] + bb[2]) / 2
        y = cy + cap / 2
        if y + bb[1] < ry0:
            y = ry0 - bb[1]
        if y + bb[3] > ry1:
            y = ry1 - bb[3]
        d.text((x, y), text, font=f, fill=fill, anchor="ls",
               stroke_width=sw, stroke_fill=stroke if stroke else None)
        caps.append(cap / K)
    return min(caps)


# ---------------------------------------------------------------- one label
def render_label(job, sizes, themes, fonts):
    s = sizes[job["size"]]
    th = themes[job["theme"]]
    W, H = s["w"] + 2 * BLEED, s["h"] + 2 * BLEED
    wpx, hpx = px(W), px(H)
    seed = int(hashlib.md5(f'{job["theme"]}|{job["size"]}'.encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)

    tdir = ROOT / "themes" / job["theme"]
    if th.get("scene") and (tdir / th["scene"].get("wide", "wide.jpg")).exists():
        img, tbox = scene_render(th, tdir, s, job["size"], wpx, hpx)
        lines = [job["name"]] + ([job["line2"]] if job.get("line2") else [])
        box_px = tuple(px(BLEED + v) for v in tbox)
        cap_mm = draw_text_block(img, fonts, job["font"], lines, box_px, th.get("text", {}),
                                 th["scene"].get("cap_frac", 0.52))
        return img, cap_mm
    art = tdir / f'{job["size"]}.png'
    pattern = tdir / "pattern.png"
    if th.get("pattern") and pattern.exists():
        img = tile_pattern(pattern, wpx, hpx, th.get("pattern_mm", 30), th.get("tile_mode", "repeat"))
    elif th.get("art") and art.exists():
        img = Image.open(art).convert("RGB").resize((wpx, hpx), Image.LANCZOS)
    else:
        if th.get("art"):
            warn(f'theme {job["theme"]} has no art for size {job["size"]} ({art}); using its colours')
        bg = th.get("bg", {"colors": ["#FFFFFF"]})
        img = gradient(wpx, hpx, bg["colors"], bg.get("angle", 0))
        layer = motif_layer(wpx, hpx, th.get("motif", {"type": "none"}), rng)
        if layer is not None:
            img.paste(layer, (0, 0), layer)

    # layout in mm, relative to the cut box (cut box starts at BLEED)
    w, h = s["w"], s["h"]
    character = tdir / "character.png"
    has_char = bool(th.get("character")) and character.exists()
    use_icon = s.get("icon") and (th.get("icon") or has_char)
    lines = [job["name"]] + ([job["line2"]] if job.get("line2") else [])
    if s["shape"] == "round":
        if use_icon:
            ib = w * 0.28
            icon_box = (w / 2 - ib / 2, h * 0.11, ib)
            tbox = (w * 0.12, h * 0.42, w * 0.88, h * 0.72)
        else:
            tbox = (w * 0.10, h * 0.30, w * 0.90, h * 0.70)
    elif h >= w * 0.8:   # square-ish
        pad = max(SAFE, s.get("r", 0) * 0.6)
        if use_icon:
            ib = h * 0.42
            icon_box = (w / 2 - ib / 2, pad + h * 0.02, ib)
            tbox = (pad, h * 0.52, w - pad, h - pad - h * 0.04)
        else:
            tbox = (pad, h * 0.25, w - pad, h * 0.75)
    else:
        r = s.get("r", 0)
        pad = max(SAFE, min(r * 0.45, h * 0.12))
        if use_icon:
            ib = h - 2 * pad
            icon_box = (pad + r * 0.15, pad, ib)
            tbox = (pad + r * 0.15 + ib + 1.2, pad, w - pad - r * 0.3, h - pad)
        else:
            tbox = (pad + r * 0.3, pad, w - pad - r * 0.3, h - pad)

    if use_icon:
        ix, iy, isz = icon_box
        if has_char:
            ic = Image.open(character).convert("RGBA")
            sc = px(isz) / max(ic.size)
            ic = ic.resize((max(1, int(ic.width * sc)), max(1, int(ic.height * sc))), Image.LANCZOS)
            ox = px(BLEED + ix) + (px(isz) - ic.width) // 2
            oy = px(BLEED + iy) + (px(isz) - ic.height) // 2
            img.paste(ic, (ox, oy), ic)
        else:
            ic = icon_image(th["icon"], px(isz))
            img.paste(ic, (px(BLEED + ix), px(BLEED + iy)), ic)

    box_px = tuple(px(BLEED + v) for v in tbox)
    cap_mm = draw_text_block(img, fonts, job["font"], lines, box_px, th.get("text", {}))
    return img, cap_mm


# ---------------------------------------------------------------- packing
def keepouts():
    k = REG_KEEPOUT
    return [(0, 0, k, k), (PAGE_W - k, 0, PAGE_W, k), (0, PAGE_H - k, k, PAGE_H)]


def overlaps(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def pack(jobs, sizes):
    """Shelf packing, biggest labels first. Returns list of pages, each a list of (job, x, y) cut-box top-left in mm."""
    ko = keepouts()
    order = sorted(range(len(jobs)), key=lambda i: (-sizes[jobs[i]["size"]]["h"], -sizes[jobs[i]["size"]]["w"], i))
    pages, page = [], []
    y = MARGIN + BLEED
    queue = list(order)
    while queue:
        sz = sizes[jobs[queue[0]]["size"]]
        w, h = sz["w"], sz["h"]
        if y + h + BLEED > PAGE_H - MARGIN:
            pages.append(page)
            page, y = [], MARGIN + BLEED
        x = MARGIN + BLEED
        placed_in_row = 0
        while queue and x + w + BLEED <= PAGE_W - MARGIN:
            j = jobs[queue[0]]
            if (sizes[j["size"]]["w"], sizes[j["size"]]["h"]) != (w, h):
                break
            r = (x - BLEED, y - BLEED, x + w + BLEED, y + h + BLEED)
            if not any(overlaps(r, k) for k in ko):
                page.append((queue.pop(0), x, y))
                placed_in_row += 1
            x += w + GAP
        y += h + GAP
        if placed_in_row == 0 and y + h + BLEED > PAGE_H - MARGIN and not page:
            raise SystemExit(f"Label size {w}x{h} mm does not fit on the sheet")
    if page:
        pages.append(page)
    return pages


# ---------------------------------------------------------------- cut files
def rrect_points(x, y, w, h, r, seg=12):
    r = min(r, w / 2, h / 2)
    if r <= 0:
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    pts = []
    for cx, cy, a0 in ((x + w - r, y + r, -90), (x + w - r, y + h - r, 0), (x + r, y + h - r, 90), (x + r, y + r, 180)):
        for i in range(seg + 1):
            a = math.radians(a0 + 90 * i / seg)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def circle_points(cx, cy, r, seg=96):
    return [(cx + r * math.cos(2 * math.pi * i / seg), cy + r * math.sin(2 * math.pi * i / seg)) for i in range(seg)]


def shape_points(s, x, y):
    if s["shape"] == "round":
        return circle_points(x + s["w"] / 2, y + s["h"] / 2, s["w"] / 2)
    return rrect_points(x, y, s["w"], s["h"], s.get("r", 0))


def write_dxf(path, polylines, closed=True):
    """Minimal R12 DXF, mm, y flipped so it matches the page when imported."""
    out = ["0", "SECTION", "2", "ENTITIES"]
    for pts in polylines:
        out += ["0", "POLYLINE", "8", "CUT", "66", "1", "70", "1" if closed else "0", "10", "0", "20", "0", "30", "0"]
        for x, y in pts:
            out += ["0", "VERTEX", "8", "CUT", "10", f"{x:.4f}", "20", f"{PAGE_H - y:.4f}", "30", "0"]
        out += ["0", "SEQEND", "8", "CUT"]
    out += ["0", "ENDSEC", "0", "EOF"]
    Path(path).write_text("\n".join(out) + "\n", encoding="ascii")


def write_svg(path, placed, sizes):
    els = []
    for job, x, y in placed:
        s = sizes[job["size"]]
        if s["shape"] == "round":
            els.append(f'<circle cx="{x + s["w"] / 2:.3f}" cy="{y + s["h"] / 2:.3f}" r="{s["w"] / 2:.3f}"/>')
        else:
            els.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{s["w"]}" height="{s["h"]}" rx="{s.get("r", 0)}" ry="{s.get("r", 0)}"/>')
    Path(path).write_text(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{PAGE_W}mm" height="{PAGE_H}mm" viewBox="0 0 {PAGE_W} {PAGE_H}">\n'
        f'<g fill="none" stroke="#FF0000" stroke-width="0.2">\n' + "\n".join(els) + "\n</g>\n</svg>\n", encoding="utf-8")


def laminate_notch_files(folder):
    n, e = LAMINATE_NOTCH, 1.0
    ls = [[(n, -e), (n, n), (-e, n)],
          [(PAGE_W - n, -e), (PAGE_W - n, n), (PAGE_W + e, n)],
          [(-e, PAGE_H - n), (n, PAGE_H - n), (n, PAGE_H + e)]]
    write_dxf(folder / "laminate_notches.dxf", ls, closed=False)


# ---------------------------------------------------------------- previews
def holo(img):
    """Rough holographic look for previews and listing images only (never printed)."""
    w, h = img.size
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    t = (xs / w * 0.8 + ys / h * 0.5) * 2.2
    r = 0.5 + 0.5 * np.sin(2 * np.pi * t)
    g = 0.5 + 0.5 * np.sin(2 * np.pi * (t + 1 / 3))
    b = 0.5 + 0.5 * np.sin(2 * np.pi * (t + 2 / 3))
    rb = Image.fromarray((np.dstack([r, g, b]) * 255).astype(np.uint8), "RGB")
    out = Image.blend(img.convert("RGB"), ImageChops.soft_light(img.convert("RGB"), rb), 0.75)
    sheen = Image.fromarray((np.clip(1 - np.abs((xs / w - ys / h * 0.4) - 0.45) * 7, 0, 1) * 90).astype(np.uint8), "L")
    return Image.composite(Image.new("RGB", (w, h), (255, 255, 255)), out, sheen)


def cut_mask(s, scale_px_per_mm, with_bleed=True):
    off = BLEED if with_bleed else 0
    W, H = s["w"] + 2 * off, s["h"] + 2 * off
    m = Image.new("L", (int(round(W * scale_px_per_mm)), int(round(H * scale_px_per_mm))), 0)
    d = ImageDraw.Draw(m)
    box = [off * scale_px_per_mm, off * scale_px_per_mm, (off + s["w"]) * scale_px_per_mm, (off + s["h"]) * scale_px_per_mm]
    if s["shape"] == "round":
        d.ellipse(box, fill=255)
    else:
        d.rounded_rectangle(box, radius=s.get("r", 0) * scale_px_per_mm, fill=255)
    return m


def finished_label(img, s, finish, scale=None):
    """Label as the buyer sees it: cut to shape, optional holo look, transparent outside."""
    scale = scale or K
    if scale != K:
        img = img.resize((int(round((s["w"] + 2 * BLEED) * scale)), int(round((s["h"] + 2 * BLEED) * scale))), Image.LANCZOS)
    if finish == "holographic":
        img = holo(img)
    m = cut_mask(s, scale)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img.convert("RGB"), (0, 0), m)
    o = int(round(BLEED * scale))
    return out.crop((o, o, out.width - o, out.height - o))


def ui_font(fonts, size):
    for fid in (3, 1, 6):
        try:
            return fonts.get(fid, size)
        except SystemExit:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def page_proof(path, placed, renders, sizes, notch, dpi=150):
    k = dpi / 25.4
    img = Image.new("RGB", (int(PAGE_W * k), int(PAGE_H * k)), "white")
    d = ImageDraw.Draw(img)
    for x0, y0, x1, y1 in keepouts():
        d.rectangle((x0 * k, y0 * k, x1 * k, y1 * k), fill=(236, 236, 240))
        for i in range(-int(REG_KEEPOUT), int(REG_KEEPOUT), 4):
            d.line(((x0 + max(0, i)) * k, (y0 + max(0, -i)) * k, (x0 + min(REG_KEEPOUT, REG_KEEPOUT + i)) * k,
                    (y0 + min(REG_KEEPOUT, REG_KEEPOUT - i)) * k), fill=(210, 210, 218))
    for job, x, y in placed:
        s = sizes[job["size"]]
        r = renders[job["key"]][0].resize((int(round((s["w"] + 2 * BLEED) * k)), int(round((s["h"] + 2 * BLEED) * k))), Image.LANCZOS)
        img.paste(r, (int(round((x - BLEED) * k)), int(round((y - BLEED) * k))))
    for job, x, y in placed:
        pts = shape_points(sizes[job["size"]], x, y)
        d.line([(a * k, b * k) for a, b in pts + [pts[0]]], fill=(255, 0, 0), width=1)
    if notch:
        n = LAMINATE_NOTCH
        for poly in ([(n, 0), (n, n), (0, n)], [(PAGE_W - n, 0), (PAGE_W - n, n), (PAGE_W, n)], [(0, PAGE_H - n), (n, PAGE_H - n), (n, PAGE_H)]):
            d.line([(a * k, b * k) for a, b in poly], fill=(0, 140, 255), width=2)
    img.save(path)


# ---------------------------------------------------------------- order input
def read_order(path):
    p = Path(path)
    if p.suffix.lower() == ".csv":
        rows = list(csv.DictReader(p.open(encoding="utf-8-sig")))
        if not rows:
            raise SystemExit("Order CSV is empty")
        return {"order_id": rows[0].get("order_id") or p.stem, "items": rows}
    o = json.loads(p.read_text(encoding="utf-8"))
    o.setdefault("order_id", p.stem)
    for it in o["items"]:
        it.setdefault("finish", o.get("finish", "matte"))
    return o


def clean(text):
    return unicodedata.normalize("NFC", " ".join(str(text or "").split()))


def expand(order, packs, sizes, themes, fonts, finishes):
    jobs, problems = [], []
    for n, it in enumerate(order["items"], 1):
        name, line2 = clean(it.get("name")), clean(it.get("line2"))
        fid = int(it.get("font") or 1)
        theme, pack_id = it.get("theme"), it.get("pack")
        finish = (it.get("finish") or "matte").strip().lower()
        tag = f"item {n} ({name or 'no name'})"
        if not name:
            problems.append(f"{tag}: name is empty")
        if theme not in themes:
            problems.append(f"{tag}: unknown theme '{theme}' (choices: {', '.join(themes)})")
        if pack_id not in packs:
            problems.append(f"{tag}: unknown pack '{pack_id}' (choices: {', '.join(packs)})")
        if finish not in finishes:
            problems.append(f"{tag}: unknown finish '{finish}' (choices: {', '.join(finishes)})")
        if fid not in fonts.entries:
            problems.append(f"{tag}: unknown font {fid}")
        else:
            miss = fonts.missing_glyphs(fid, name + line2)
            if miss:
                ok = [str(f) for f in fonts.entries if not fonts.missing_glyphs(f, name + line2)]
                problems.append(f"{tag}: font {fid} has no {' '.join(miss)} - fonts that do: {', '.join(ok) or 'none'}")
        if problems:
            continue
        for size_id, count in packs[pack_id]["contents"].items():
            for _ in range(int(count)):
                jobs.append({"item": n, "name": name, "line2": line2, "font": fid, "theme": theme,
                             "size": size_id, "finish": finish,
                             "key": (size_id, name, line2, fid, theme)})
    if problems:
        print("Order has problems, nothing was generated:")
        for p in problems:
            print("  -", p)
        sys.exit(1)
    return jobs


# ---------------------------------------------------------------- commands
def build(args, cfg):
    sizes, packs, themes, finishes, fonts = cfg
    order = read_order(args.order)
    jobs = expand(order, packs, sizes, themes, fonts, finishes)
    out = Path(args.out) / str(order["order_id"])
    out.mkdir(parents=True, exist_ok=True)

    renders = {}
    for j in jobs:
        if j["key"] not in renders:
            img, cap = render_label(j, sizes, themes, fonts)
            renders[j["key"]] = (img, cap)
            mini_ok = fonts.entries[j["font"]].get("mini_ok", True)
            if cap < MIN_CAP_MM or (j["size"] == "mini" and not mini_ok):
                warn(f'"{j["name"]}" on {j["size"]} labels: capitals only {cap:.1f} mm high with font {j["font"]} - may be hard to read')

    # customer proof: one of each label design, as it will look
    uniq = []
    for j in jobs:
        if all(u["key"] != j["key"] or u["finish"] != j["finish"] for u in uniq):
            uniq.append(j)
    customer_proof(out / "customer_proof.png", order, uniq, renders, sizes, fonts, finishes)

    for finish in sorted({j["finish"] for j in jobs}):
        fjobs = [j for j in jobs if j["finish"] == finish]
        fdir = out / finish
        fdir.mkdir(exist_ok=True)
        pages = pack(fjobs, sizes)
        fin = finishes[finish]
        c = canvas.Canvas(str(fdir / "print.pdf"), pagesize=(PAGE_W * mm, PAGE_H * mm))
        c.setTitle(f'{order["order_id"]} {finish}')
        info = [f'Order {order["order_id"]} - finish: {fin["label"]}',
                f'Media: {fin["media"]}  |  Laminate: {fin["laminate"]}', ""]
        for pi, page in enumerate(pages, 1):
            placed = [(fjobs[i], x, y) for i, x, y in page]
            for job, x, y in placed:
                s = sizes[job["size"]]
                img = renders[job["key"]][0]
                c.drawImage(ImageReader(img), (x - BLEED) * mm, (PAGE_H - y - s["h"] - BLEED) * mm,
                            width=(s["w"] + 2 * BLEED) * mm, height=(s["h"] + 2 * BLEED) * mm)
            c.showPage()
            polys = [shape_points(sizes[j["size"]], x, y) for j, x, y in placed]
            write_dxf(fdir / f"cut_p{pi:02d}.dxf", polys)
            write_svg(fdir / f"cut_p{pi:02d}.svg", placed, sizes)
            page_proof(fdir / f"proof_p{pi:02d}.png", placed, renders, sizes, fin.get("notch_laminate"))
            xs = [p[0] for poly in polys for p in poly]
            ys = [p[1] for poly in polys for p in poly]
            info.append(f"Page {pi}: {len(placed)} labels. Cut file cut_p{pi:02d}.dxf -> in Studio set "
                        f"X {min(xs):.2f}  Y {min(ys):.2f}  W {max(xs) - min(xs):.2f}  H {max(ys) - min(ys):.2f} mm")
        c.save()
        if fin.get("notch_laminate"):
            laminate_notch_files(fdir)
            info += ["", f"Shiny laminate: cut a {LAMINATE_NOTCH:.0f} x {LAMINATE_NOTCH:.0f} mm square off the top-left, top-right "
                         "and bottom-left corners of the laminate sheet (or cut laminate_notches.dxf on the Cameo), "
                         "so the registration marks stay uncovered."]
        info += ["", "Steps: print at 100 % one sheet at a time -> let dry (overnight for best results) -> laminate "
                     "-> load on the mat -> import the cut file, place it at the X/Y above -> kiss cut (vinyl + laminate, not the backing)."]
        (fdir / "info.txt").write_text("\n".join(info) + "\n", encoding="utf-8")
        print(f"  {finish}: {len(fjobs)} labels on {len(pages)} sheet(s) -> {fdir}")
    print(f"  customer proof -> {out / 'customer_proof.png'}")


def customer_proof(path, order, uniq, renders, sizes, fonts, finishes):
    scale = 12  # px per mm
    pad = 40
    tiles = []
    for j in uniq:
        s = sizes[j["size"]]
        tiles.append((j, finished_label(renders[j["key"]][0], s, j["finish"], scale)))
    width = 1600
    x, y, rowh = pad, 170, 0
    pos = []
    for j, t in tiles:
        if x + t.width > width - pad:
            x, y, rowh = pad, y + rowh + 70, 0
        pos.append((j, t, x, y))
        x += t.width + 40
        rowh = max(rowh, t.height)
    H = y + rowh + 70 + pad
    img = Image.new("RGB", (width, H), (246, 244, 250))
    d = ImageDraw.Draw(img)
    d.text((pad, 40), "Please check the spelling", font=ui_font(fonts, 46), fill=(40, 30, 60))
    names = ", ".join(dict.fromkeys(j["name"] + (f' / {j["line2"]}' if j["line2"] else "") for j in uniq))
    d.text((pad, 104), f'Order {order["order_id"]}: {names}', font=ui_font(fonts, 28), fill=(90, 80, 110))
    small = ui_font(fonts, 22)
    for j, t, x, y in pos:
        sh = Image.new("RGBA", (t.width + 30, t.height + 30), (0, 0, 0, 0))
        sh.paste((0, 0, 0, 60), (15, 18), t.getchannel("A"))
        sh = sh.filter(ImageFilter.GaussianBlur(6))
        img.paste(sh, (x - 15, y - 12), sh)
        img.paste(t, (x, y), t)
        s = sizes[j["size"]]
        d.text((x, y + t.height + 12), f'{s["label"]} - {finishes[j["finish"]]["label"]}', font=small, fill=(110, 100, 130))
    img.save(path)


def cmd_fontchart(args, cfg):
    sizes, packs, themes, finishes, fonts = cfg
    text = clean(args.text or fonts.sample)
    rows = list(fonts.entries.values())
    cols = 2
    cw, rh = 900, 170
    img = Image.new("RGB", (cw * cols, 140 + rh * math.ceil(len(rows) / cols) + 40), "white")
    d = ImageDraw.Draw(img)
    d.text((40, 40), "Choose your font", font=ui_font(fonts, 56), fill=(40, 30, 60))
    for i, e in enumerate(rows):
        x, y = 40 + (i % cols) * cw, 140 + (i // cols) * rh
        d.rounded_rectangle((x, y, x + cw - 80, y + rh - 20), radius=24, fill=(246, 244, 250))
        d.ellipse((x + 20, y + 40, x + 90, y + 110), fill=(123, 44, 191))
        num = str(e["id"])
        nf = ui_font(fonts, 34)
        d.text((x + 55, y + 76), num, font=nf, fill="white", anchor="mm")
        try:
            f, sw, bb, cap = fit_text(fonts, e["id"], text, cw - 260, rh - 70, 0)
            d.text((x + 120, y + (rh - 20) / 2 + cap / 2), text, font=f, fill=(30, 30, 50), anchor="ls")
        except SystemExit:
            d.text((x + 120, y + 60), "(font file missing)", font=ui_font(fonts, 26), fill=(200, 0, 0))
        d.text((x + cw - 100, y + rh - 32), e["name"], font=ui_font(fonts, 20), fill=(140, 130, 160), anchor="rs")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    img.save(out / "font_chart.png")
    print("  font chart ->", out / "font_chart.png")


def cmd_themes(args, cfg):
    sizes, packs, themes, finishes, fonts = cfg
    name = clean(args.name)
    show = [sid for sid in ("large", "medium", "mini", "round") if sid in sizes]
    scale = 10
    tiles = []
    for tid, th in themes.items():
        row = []
        for sid in show:
            j = {"size": sid, "theme": tid, "name": name, "line2": "", "font": args.font}
            img, _ = render_label(j, sizes, themes, fonts)
            row.append(finished_label(img, sizes[sid], args.finish, scale))
        tiles.append((th["name"], row))
    W = 60 + sum(t.width for t in tiles[0][1]) + 40 * len(show) + 260
    H = 60 + sum(max(t.height for t in r) + 60 for _, r in tiles)
    img = Image.new("RGB", (W, H), (246, 244, 250))
    d = ImageDraw.Draw(img)
    y = 40
    for tname, row in tiles:
        d.text((40, y + 40), tname, font=ui_font(fonts, 30), fill=(60, 50, 80))
        x = 300
        for t in row:
            img.paste(t, (x, y), t)
            x += t.width + 40
        y += max(t.height for t in row) + 60
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    fn = out / f"themes_{args.finish}.png"
    img.save(fn)
    print("  theme sampler ->", fn)


def cmd_packs(args, cfg):
    sizes, packs, themes, finishes, fonts = cfg
    per_sheet = {}
    for sid in sizes:
        per_sheet[sid] = len(pack([{"size": sid}] * 400, sizes)[0])
    print("  Labels per full sheet:", ", ".join(f"{sid} {n}" for sid, n in per_sheet.items()))
    rows = []
    for pid, p in packs.items():
        jobs = [{"size": sid} for sid, n in p["contents"].items() for _ in range(n)]
        sheets = len(pack(jobs, sizes))
        for fid, f in finishes.items():
            rows.append({"variation_1_size_quantity": p["label"], "variation_2_finish": f["label"], "pack_id": pid,
                         "finish_id": fid, "labels": len(jobs), "sheets": sheets,
                         "material_cost": round(sheets * float(f.get("cost_per_sheet", 0)), 2), "price": ""})
        print(f"  {p['label']:<28} {len(jobs):>4} labels  {sheets} sheet(s)")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    with (out / "etsy_variations.csv").open("w", newline="", encoding="utf-8") as fh:
        wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    print(f"  {len(rows)} Etsy variation combinations (limit 70) ->", out / "etsy_variations.csv")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fonts-config", help="alternative fonts.json")
    ap.add_argument("--fonts-dir", default=str(ROOT / "fonts"))
    sub = ap.add_subparsers(dest="cmd", required=True)
    o = sub.add_parser("order")
    o.add_argument("order")
    o.add_argument("--out", default=str(ROOT / "out"))
    fc = sub.add_parser("fontchart")
    fc.add_argument("--text")
    fc.add_argument("--out", default=str(ROOT / "out" / "listing"))
    t = sub.add_parser("themes")
    t.add_argument("--name", default="Emma")
    t.add_argument("--font", type=int, default=1)
    t.add_argument("--finish", default="matte")
    t.add_argument("--out", default=str(ROOT / "out" / "listing"))
    pk = sub.add_parser("packs")
    pk.add_argument("--out", default=str(ROOT / "out" / "listing"))
    args = ap.parse_args()

    sizes = load_json("sizes.json")["sizes"]
    packs = load_json("packs.json")["packs"]
    themes = load_json("themes.json")["themes"]
    finishes = load_json("finishes.json")["finishes"]
    fonts = FontStore(load_json("fonts.json", args.fonts_config), args.fonts_dir)
    cfg = (sizes, packs, themes, finishes, fonts)
    {"order": build, "fontchart": cmd_fontchart, "themes": cmd_themes, "packs": cmd_packs}[args.cmd](args, cfg)


if __name__ == "__main__":
    main()
