"""Remove a white/hazy band left at the top of a Flow square (from the wide's letterbox); re-square from the bottom-left."""
import sys, numpy as np
from PIL import Image
def clean(im):
    a = np.asarray(im.convert("RGB")).astype(np.int16); H, W, _ = a.shape
    mn, mx = a.min(2), a.max(2)
    whiteish = ((mn > 236) & ((mx - mn) < 14)).mean(1)   # per-row fraction of near-white pixels
    band = 0
    while band < int(H * 0.45) and whiteish[band] > 0.85: band += 1
    if band < H * 0.015: return im, 0
    band += int(H * 0.01)                                  # skip the soft edge too
    s = H - band
    return im.crop((0, band, s, H)), band
if __name__ == "__main__":
    im, b = clean(Image.open(sys.argv[1])); im.save(sys.argv[2], quality=95); print(sys.argv[2], b, im.size)
