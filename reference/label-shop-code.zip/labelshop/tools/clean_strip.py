"""Cut a Flow 'wide' image down to just the artwork strip: drop the white letterbox, any frame line and white padding.
usage: python clean_strip.py in.jpg out.jpg"""
import sys, numpy as np
from PIL import Image

def clean(im):
    a = np.asarray(im.convert("RGB")).astype(np.int16)
    mn, mx = a.min(2), a.max(2)
    ink = (mn < 232) | ((mx - mn) > 25)
    H, W = ink.shape
    rows = np.where(ink.mean(1) > 0.5)[0]
    y0, y1 = rows.min(), rows.max()
    cols = np.where(ink[y0:y1 + 1].mean(0) > 0.5)[0]
    x0, x1 = cols.min(), cols.max()
    white = (mn > 238) & ((mx - mn) < 12)
    def shrink(lo, hi, frac_fn, limit):
        for _ in range(limit):
            if frac_fn(lo) > 0.35: lo += 1
            else: break
        for _ in range(limit):
            if frac_fn(hi) > 0.35: hi -= 1
            else: break
        return lo, hi
    # pass 1: skip a frame line + white padding (rows/cols that are mostly white, or a uniform dark line)
    for _ in range(2):
        lim_y, lim_x = int((y1 - y0) * 0.08), int((x1 - x0) * 0.03)
        y0, y1 = shrink(y0, y1, lambda y: white[y, x0:x1].mean(), lim_y)
        x0, x1 = shrink(x0, x1, lambda x: white[y0:y1, x].mean(), lim_x)
    # pass 2: a fixed safety shave (frame lines are a few px)
    s = max(4, int((y1 - y0) * 0.012))
    out = im.crop((x0 + s, y0 + s, x1 - s + 1, y1 - s + 1))
    # pass 3: a near-white edge (white padding inside a frame) -> step past it and the frame line
    g = np.asarray(out.convert("L")).astype(np.float32); h, w = g.shape
    def edge(vals):
        i = 0
        while i < 40 and vals(i) > 247: i += 1
        return i + 8 if 0 < i < 40 else 0
    t = edge(lambda i: g[i, w//10:-w//10].mean()); b = edge(lambda i: g[h-1-i, w//10:-w//10].mean())
    l = edge(lambda i: g[h//10:-h//10, i].mean()); r = edge(lambda i: g[h//10:-h//10, w-1-i].mean())
    return out.crop((l, t, w - r, h - b))

if __name__ == "__main__":
    out = clean(Image.open(sys.argv[1]))
    out.save(sys.argv[2], quality=95); print(sys.argv[2], out.size, round(out.width / out.height, 2))
