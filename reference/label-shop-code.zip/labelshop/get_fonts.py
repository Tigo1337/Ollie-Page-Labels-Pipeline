#!/usr/bin/env python3
"""Download the label fonts (and their license files) from Google Fonts' GitHub repo.

Run once on your PC:   python get_fonts.py
Fonts land in ./fonts, licenses in ./fonts/licenses. Already-downloaded fonts are skipped.
Only standard-library modules are used.
"""
import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = "https://raw.githubusercontent.com/google/fonts/main/"
API = "https://api.github.com/repos/google/fonts/contents/"


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "label-fonts-downloader"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def raw_url(repo_dir, name):
    return RAW + repo_dir + "/" + urllib.parse.quote(name)


def list_dir(repo_dir):
    return json.loads(fetch(API + repo_dir))


def main():
    cfg = json.loads((ROOT / "config" / "fonts.json").read_text(encoding="utf-8"))
    out = ROOT / "fonts"
    lic = out / "licenses"
    lic.mkdir(parents=True, exist_ok=True)
    failed = []
    for f in cfg["fonts"]:
        dest = out / f["file"]
        if dest.exists():
            print(f"  ok (already here)  {f['id']:>2}  {f['name']}")
            continue
        try:
            data = fetch(raw_url(f["repo_dir"], f["file"]))
            dest.write_bytes(data)
            print(f"  downloaded         {f['id']:>2}  {f['name']}")
        except Exception:
            # File name changed upstream: look in the folder for the closest .ttf
            try:
                ttfs = [e["name"] for e in list_dir(f["repo_dir"]) if e["name"].endswith(".ttf")]
                pick = next((n for n in ttfs if "Italic" not in n), None)
                if not pick:
                    raise RuntimeError("no .ttf in folder")
                dest = out / pick
                dest.write_bytes(fetch(raw_url(f["repo_dir"], pick)))
                print(f"  downloaded         {f['id']:>2}  {f['name']}  (as {pick}; update 'file' in config/fonts.json)")
            except Exception as e:
                failed.append(f["name"])
                print(f"  FAILED             {f['id']:>2}  {f['name']}: {e}")
                continue
        # license file sits next to the font in the repo
        for lname in ("OFL.txt", "LICENSE.txt"):
            try:
                (lic / f"{f['file'].split('[')[0].split('-')[0]}_{lname}").write_bytes(
                    fetch(raw_url(f["repo_dir"], lname)))
                break
            except Exception:
                pass
    if failed:
        print("\nCould not download:", ", ".join(failed))
        sys.exit(1)
    print("\nAll fonts ready in", out)


if __name__ == "__main__":
    main()
