#!/usr/bin/env python3
"""Cut characters out of an AI-generated character sheet.

The sheet must be a grid of stickers on one flat background colour (e.g. medium grey).
Each cell's character is saved as themes/<theme id>/character.png with a transparent background.

  python extract_characters.py sheet1.png --grid 3x3 --themes dino,unicorn,fox,panda,axolotl,bunny,space-cat,shark,dragon

Use '-' in --themes to skip a cell. Check the results in out/extract_preview.png.
"""
import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parent


def bg_colour(a):
    h, w = a.shape[:2]
    k = max(4, min(h, w) // 50)
    corners = np.concatenate([a[:k, :k].reshape(-1, 3), a[:k, -k:].reshape(-1, 3),
                              a[-k:, :k].reshape(-1, 3), a[-k:, -k:].reshape(-1, 3)])
    return np.median(corners, axis=0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sheet")
    ap.add_argument("--grid", default="3x3", help="ROWSxCOLS")
    ap.add_argument("--themes", required=True, help="comma-separated theme ids, row by row")
    ap.add_argument("--tol", type=float, default=28, help="colour distance treated as background")
    ap.add_argument("--soft", type=float, default=22, help="width of the soft edge ramp")
    args = ap.parse_args()

    rows, cols = (int(v) for v in args.grid.lower().split("x"))
    ids = [t.strip() for t in args.themes.split(",")]
    if len(ids) != rows * cols:
        raise SystemExit(f"--themes needs {rows * cols} entries (use - to skip), got {len(ids)}")

    img = Image.open(args.sheet).convert("RGB")
    a = np.asarray(img).astype(np.float32)
    bg = bg_colour(a)
    dist = np.sqrt(((a - bg) ** 2).sum(-1))
    alpha = np.clip((dist - args.tol) / args.soft, 0, 1)
    # remove specks and fill pinholes
    m = Image.fromarray((alpha > 0.5).astype(np.uint8) * 255, "L")
    m = m.filter(ImageFilter.MinFilter(5)).filter(ImageFilter.MaxFilter(5))
    solid = np.asarray(m) > 0
    near = np.asarray(m.filter(ImageFilter.MaxFilter(7))) > 0
    alpha = alpha * near   # keep soft edges next to real shapes, drop isolated specks

    # un-mix the background colour from soft edge pixels
    al = alpha[..., None]
    rgb = np.where(al > 0.02, (a - (1 - al) * bg) / np.maximum(al, 0.02), a)
    rgb = np.clip(rgb, 0, 255)

    H, W = solid.shape
    ch, cw = H / rows, W / cols
    previews = []
    for i, tid in enumerate(ids):
        if tid == "-":
            continue
        r, c = divmod(i, cols)
        y0, y1, x0, x1 = int(r * ch), int((r + 1) * ch), int(c * cw), int((c + 1) * cw)
        cell = solid[y0:y1, x0:x1]
        ys, xs = np.nonzero(cell)
        if len(ys) == 0:
            print(f"  {tid}: nothing found in cell {r + 1},{c + 1}")
            continue
        pad = 6
        by0, by1 = max(0, ys.min() - pad), min(cell.shape[0], ys.max() + pad + 1)
        bx0, bx1 = max(0, xs.min() - pad), min(cell.shape[1], xs.max() + pad + 1)
        if by0 == 0 or bx0 == 0 or by1 == cell.shape[0] or bx1 == cell.shape[1]:
            print(f"  {tid}: touches its cell edge - check it isn't cut off or merged with a neighbour")
        sl = (slice(y0 + by0, y0 + by1), slice(x0 + bx0, x1 - (cell.shape[1] - bx1)))
        rgba = np.dstack([rgb[sl], alpha[sl] * 255]).astype(np.uint8)
        out = Image.fromarray(rgba, "RGBA")
        d = ROOT / "themes" / tid
        d.mkdir(parents=True, exist_ok=True)
        out.save(d / "character.png")
        previews.append(out)
        print(f"  {tid}: {out.width}x{out.height}px -> {d / 'character.png'}")

    if previews:
        th = 240
        strip = Image.new("RGBA", (sum(int(p.width * th / p.height) + 20 for p in previews) + 20, th + 40), (60, 140, 90, 255))
        x = 20
        for p in previews:
            q = p.resize((int(p.width * th / p.height), th), Image.LANCZOS)
            strip.paste(q, (x, 20), q)
            x += q.width + 20
        (ROOT / "out").mkdir(exist_ok=True)
        strip.save(ROOT / "out" / "extract_preview.png")
        print("  preview ->", ROOT / "out" / "extract_preview.png")


if __name__ == "__main__":
    main()
