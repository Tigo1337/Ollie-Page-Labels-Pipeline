import json, sys
D = {d[0]: d for d in json.load(open('designs.json'))}
STYLE = ("Kawaii flat vector illustration for a children's name label: chunky simple rounded shapes, big shiny dark eyes, "
         "small rosy cheeks, happy smile, clean dark outlines, bright cheerful flat colours with soft simple shading, "
         "no texture, no text, no letters, no numbers, no logo, no frame, no border.")
def wide(i):
    _, name, kind, subj, scene, *_ = D[i]
    lead = (f"On the left fifth of the banner: {subj}, full body and fully inside the banner, facing right, big and clear."
            if kind == "c" else f"On the left fifth of the banner: {subj}, filling the full height.")
    return ("A very wide panoramic banner, about 4 times wider than tall, placed across the middle of a plain pure white "
            "image, with empty pure white space above and below the banner. The banner artwork fills the banner edge to edge "
            f"with no rounded corners. {STYLE} {lead} The rest of the banner, to the right: {scene}, kept calm, simple and "
            "low-detail through the middle so a child's name can be printed over it, with a few small accents near the "
            "right end. Everything important stays inside the banner.")
def square(i):
    _, name, kind, subj, scene, *_ = D[i]
    if kind == "c":
        return (f"Square full-bleed illustration, same style as the reference image. {STYLE} The exact same character as in "
                f"the reference image ({subj}): identical colours, markings, proportions, face and accessories. The character "
                f"is smaller, in the lower left third, standing in the same scene: {scene}. The whole upper half is calm, open, "
                "simple background with no objects, so a name can be printed there. The artwork fills the whole square to every "
                "edge: no white margins, no circle, no badge, no sticker border.")
    return (f"Square full-bleed illustration, same style and colours as the reference image. {STYLE} A cluster of the same motifs "
            f"({subj}) along the bottom edge and lower corners, and the same background ({scene}) everywhere else. The whole upper "
            "half is calm with only the light background pattern, so a name can be printed there. The artwork fills the whole "
            "square to every edge: no white margins, no circle, no badge.")
if __name__ == "__main__":
    print((wide if sys.argv[1] == "w" else square)(sys.argv[2]))
