# Label shop pipeline

Personalised name labels, printed on the Epson ET-2980 and kiss-cut on the Silhouette Cameo 5.

## One-time setup (on your PC)

```
pip install pillow reportlab numpy fonttools
python get_fonts.py
```

`get_fonts.py` downloads the 17 label fonts and their license files into `fonts/`.
They're all Google Fonts under the SIL Open Font License or Apache 2.0, so you can use them on products you sell.
The one thing you can't do is sell or give away the font files themselves.

## Daily use

1. Put the order in `orders/` as JSON (see `orders/sample_order.json`) or CSV with columns
   `order_id,name,line2,font,theme,pack,finish`. One row per name; siblings in one order are fine.
2. `python label_sheet.py order orders/<file>`
3. Send `out/<order>/customer_proof.png` to the buyer through Etsy messages and wait for their OK.
4. For each finish folder (`out/<order>/matte`, `.../holographic`):
   - check `proof_pNN.png` (red = cut lines, grey = no-ink zones for the registration marks)
   - print `print.pdf` at 100 %, one sheet at a time, on printable vinyl
   - let it dry (overnight is best with dye ink), then laminate
   - gloss and holographic only: cut the three corner notches off the laminate first (34 mm squares, or cut
     `laminate_notches.dxf` on the Cameo). That keeps the registration marks readable under shiny film.
   - in Studio, open your label template (registration marks: same settings as the card template),
     import `cut_pNN.dxf`, and type the X / Y / W / H values from `info.txt`
   - kiss cut: through laminate + vinyl, not the backing. Do a test cut first.

The script refuses an order that has an unknown theme, pack or font, or a name with letters the
chosen font doesn't have (Ł, ø, ß…). It tells you which fonts do have them. It also warns when
a name gets too small to read on the minis.

## Listing images

```
python label_sheet.py fontchart                         # out/listing/font_chart.png
python label_sheet.py themes --name "Emma"              # all designs, matte
python label_sheet.py themes --name "Emma" --finish holographic
python label_sheet.py packs                             # sheets per pack + etsy_variations.csv
```

The holographic look in previews is a simulation for listing photos. It's never printed.

## Etsy listing structure

- **One listing per design** (Galaxy, Checker Pop…). Each design gets its own photos and search title.
- **Variation 1 – Size & quantity:** the packs in `config/packs.json`.
- **Variation 2 – Finish:** Matte / Glossy / Holographic (`config/finishes.json`).
  8 packs × 3 finishes = 24 combinations, under Etsy's 70 limit.
- **Personalisation questions:** Name (required), Second line (optional), Font number (from the chart).
- Prices: fill `cost_per_sheet` in `finishes.json`, run `packs`, and price from the `sheets` column.

## Changing things

| To change | Edit |
|---|---|
| Label sizes / corner radius | `config/sizes.json` |
| What's in each pack | `config/packs.json` |
| Fonts offered | `config/fonts.json` then `python get_fonts.py` |
| Designs | `config/themes.json` |
| Margins, bleed, keep-out zones | constants at the top of `label_sheet.py` |

**Illustrated designs.** For designs drawn in Gemini or similar, make a folder `themes/<theme id>/`
with one PNG per size, named `mini.png`, `large.png` and so on. Draw each at cut size plus 1.25 mm bleed per side.
Then add `"art": true` to that theme. The name and icon are still placed by the script.

**Design rule:** don't put borders or frames parallel to the cut line. A 0.3 mm cut offset is invisible
on a full-bleed background, but it shows clearly on a thin frame.
