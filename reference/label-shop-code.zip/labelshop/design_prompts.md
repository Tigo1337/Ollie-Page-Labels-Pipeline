# Design prompts (Google Flow, Nano Banana, 1:1, x1)

Each design = one **character** (cut from a character sheet) + one **seamless pattern** (tiled as the label background).
Pattern-only designs (Rainbow Sky, Daisy Checker) use a built-in icon instead of a character.

## Character sheets

Shared style block (part of both sheet prompts):

> Each character sits alone in the centre of its own cell with lots of empty space around it, on one perfectly flat, plain,
> solid medium grey background (#8C8C8C). No grid lines, no frames, no text, no shadows on the background. Style for every
> character: kawaii flat vector illustration, chunky simple rounded shapes, big shiny dark eyes, small rosy cheeks, happy
> smile, clean dark plum outline, flat bright cheerful colours with one small soft highlight, no texture, no gradients.
> Every character is surrounded by a thick, even, pure white sticker border. Full body, compact and almost square
> silhouette so it reads clearly when printed very small, turned slightly to the right.

**Sheet 1** – `--themes dino,unicorn,fox,panda,axolotl,bunny,space-cat,shark,dragon`
Row 1: green baby T-rex dinosaur with orange back spikes; white unicorn with a pastel rainbow mane and golden horn; orange
fox with a white chest and fluffy tail. Row 2: panda sitting and holding a bamboo leaf; pink axolotl with frilly gills;
white bunny with long ears holding a carrot. Row 3: cat in a little white astronaut suit with a round helmet; friendly
blue shark with a big grin; little purple dragon with tiny wings and a yellow belly.

**Sheet 2** – `--themes penguin,frog,octopus,bee,rocket,excavator,strawberry,ice-cream,soccer`
Row 1: baby penguin with a red scarf; green frog sitting on a lily pad; orange-pink octopus waving a tentacle.
Row 2: round bumblebee with see-through wings; red and white rocket with a smiling face and a little flame;
yellow excavator digger with a smiling face. Row 3: smiling strawberry with green leaves; ice cream cone with a pink
scoop and sprinkles, smiling; smiling soccer ball with tiny arms giving a thumbs up.

After download: `python extract_characters.py sheet1.png --grid 3x3 --themes <ids above>`

## Pattern tiles (save as themes/<id>/pattern.png)

Shared block for every pattern:

> A seamless repeating pattern tile for the background of a children's name sticker. Kawaii flat vector style, flat
> colours, no gradients, no texture, no text, no characters with faces. Small, evenly spaced motifs on a soft solid
> background, gentle low contrast so a dark name printed on top stays easy to read. Motifs fill the tile evenly, with
> nothing large and no empty band at any edge.

| id | background | motifs |
|---|---|---|
| dino | soft mint green | tiny palm leaves, little dino footprints, small volcanoes |
| unicorn | pale lilac | tiny stars, small clouds, mini rainbows |
| fox | warm cream | small autumn leaves, acorns, tiny mushrooms |
| panda | soft sage green | bamboo leaves and short bamboo stalks |
| axolotl | light aqua | bubbles, small water plants, tiny pebbles |
| bunny | pale pink | tiny carrots, small daisies |
| space-cat | deep navy | tiny stars, small planets, little paw prints |
| shark | light sky blue | small waves, tiny fish, bubbles |
| dragon | soft lavender | tiny flames, small gems, sparkles |
| penguin | icy pale blue | snowflakes, tiny ice cubes |
| frog | light lime green | small lily pads, tiny flowers, dots |
| octopus | soft peach | small seashells, starfish, bubbles |
| bee | butter yellow | honeycomb hexagons, tiny flowers |
| rocket | dark night blue | tiny stars, small moons, little planets |
| excavator | light sand | tiny traffic cones, small bricks, little stones |
| strawberry | pink and white gingham | tiny strawberries |
| ice-cream | soft mint | sprinkles and tiny ice cream cones |
| soccer | light grass green with faint mowing stripes | tiny soccer balls, little stars |
| rainbow-clouds | baby blue | small fluffy clouds and mini rainbows |
| daisy-checker | lilac and cream checkerboard | small white daisies |
