#!/usr/bin/env python3
"""Review sheet per design: every label size with short and long test names, as the buyer sees them.

  python design_review.py                 all scene designs -> out/review/<id>.png
  python design_review.py dino fox        only these
"""
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

import label_sheet as L

TESTS = [  # (size, name, line2, font)
    ("large", "Léo", "", 1), ("large", "Maximilien", "", 3),
    ("medium", "Émilie-Rose", "", 1), ("medium", "Alexandre", "Tremblay-Gagnon", 1),
    ("small", "Mia", "", 3), ("small", "Charlotte", "", 1),
    ("mini", "Noah", "", 1), ("mini", "Gabrielle", "", 3),
    ("round", "Zoë", "", 1), ("round", "Juliette", "", 3),
    ("square", "Liam", "", 1), ("square", "Rosalie", "", 3),
]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    fonts_cfg = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--fonts-config=")), None)
    out = Path(next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--out=")), L.ROOT / "out" / "review"))
    sizes = L.load_json("sizes.json")["sizes"]
    themes = L.load_json("themes.json")["themes"]
    fonts = L.FontStore(L.load_json("fonts.json", fonts_cfg), L.ROOT / "fonts")
    ids = args or [k for k, v in themes.items() if v.get("scene")]
    out.mkdir(parents=True, exist_ok=True)
    scale = 9
    for tid in ids:
        tiles = []
        for size, name, line2, font in TESTS:
            img, cap = L.render_label({"size": size, "theme": tid, "name": name, "line2": line2, "font": font},
                                      sizes, themes, fonts)
            tiles.append((size, name, cap, L.finished_label(img, sizes[size], "matte", scale)))
        W = 1700
        x, y, rowh, pos = 40, 110, 0, []
        for t in tiles:
            im = t[3]
            if x + im.width > W - 40:
                x, y, rowh = 40, y + rowh + 60, 0
            pos.append((t, x, y))
            x += im.width + 40
            rowh = max(rowh, im.height)
        sheet = Image.new("RGB", (W, y + rowh + 80), (246, 244, 250))
        d = ImageDraw.Draw(sheet)
        d.text((40, 30), themes[tid]["name"], font=L.ui_font(fonts, 48), fill=(40, 30, 60))
        small = L.ui_font(fonts, 20)
        for (size, name, cap, im), px_, py_ in pos:
            sh = Image.new("RGBA", (im.width + 30, im.height + 30), (0, 0, 0, 0))
            sh.paste((0, 0, 0, 55), (15, 18), im.getchannel("A"))
            sh = sh.filter(ImageFilter.GaussianBlur(6))
            sheet.paste(sh, (px_ - 15, py_ - 12), sh)
            sheet.paste(im, (px_, py_), im)
            flag = "  (small text)" if cap < L.MIN_CAP_MM else ""
            d.text((px_, py_ + im.height + 10), f"{sizes[size]['label']} - caps {cap:.1f} mm{flag}", font=small,
                   fill=(200, 40, 40) if flag else (110, 100, 130))
        sheet.save(out / f"{tid}.png")
        print("  ", tid, "->", out / f"{tid}.png")


if __name__ == "__main__":
    main()
